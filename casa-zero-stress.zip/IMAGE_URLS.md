# Image URLs - Casa Zero Stress

## CDN URLs for all assets

- **Logo C0S**: https://files.manuscdn.com/user_upload_by_module/session_file/310519663355725872/nCBXEYlQNNSJAWGI.png
- **Hero - Operaio Cantiere**: https://files.manuscdn.com/user_upload_by_module/session_file/310519663355725872/EtccHwDTowbCzPQo.png
- **WhatsApp Interface Mockup**: https://files.manuscdn.com/user_upload_by_module/session_file/310519663355725872/mSSiYVpZImbCiHeO.png
- **Cantiere Progresso**: https://files.manuscdn.com/user_upload_by_module/session_file/310519663355725872/TbBwyfIfKuKDNhjq.png
- **Team Collaboration**: https://files.manuscdn.com/user_upload_by_module/session_file/310519663355725872/FIrsCdlSmrYYqXOe.png
- **Abstract Organic Blob**: https://files.manuscdn.com/user_upload_by_module/session_file/310519663355725872/UfGOAstUGRJlxdmU.png
